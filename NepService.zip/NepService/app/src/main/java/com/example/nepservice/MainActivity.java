package com.example.nepservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView11;
    EditText UserName, Password;
    Button LogInButton, RegisterButton, forgotPasswordButton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RegisterButton = findViewById(R.id.RegisterButton);
        LogInButton = findViewById(R.id.LogInButton);
        UserName = findViewById(R.id.UserName);
        Password = findViewById(R.id.PasswordLogIn);
        textView11 = findViewById(R.id.textView11);
        forgotPasswordButton = findViewById(R.id.forgotPasswordButton);

        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new RegisterFragment()).commit();
            }
        });


        LogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String UserName1 = UserName.getText().toString();
                String Password1 = Password.getText().toString();
                if (UserName1.isEmpty() || Password1.isEmpty()) {
                    textView11.setText("Please fill in all fields!");
                } else {
                    Intent homeActivity = new Intent(MainActivity.this, HomeActivity.class);
                    homeActivity.putExtra("LI", "HA");
                    startActivity(homeActivity);
                }
            }
        });

        forgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new ForgetFragment()).commit();
            }
        });

//
  }
}