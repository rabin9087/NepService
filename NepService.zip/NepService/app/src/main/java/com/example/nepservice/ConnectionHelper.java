package com.example.nepservice;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHelper {
    String userName, password, ip, port, databaseName;
    Connection connection = null;
    String ConnectionURL;
    @SuppressLint("AuthLeak")
    public Connection connectionClass(){
        ip= "15.0.2000.5";
        databaseName = "NepService";
        userName="sa";
        password="Jackson@9087";
        port= "1433";

        StrictMode.ThreadPolicy policy;
        policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
//        ConnectionURL ="jdbc:sqlserver://" + ip + ":" + port + ";DatabaseName="+databaseName+ ";user="+userName+";password="+password+";";
     //   ConnectionURL ="jdbc:jtds:sqlserver://rabin9087;databaseName=NepService;integratedSecurity=true";
          ConnectionURL="jdbc:jtds:sqlserver://rabin9087/NepService;instance=NepService;";
                //+ port + ";databaseName="+databaseName+ ";user="+userName+";password="+password+";";

        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            connection = DriverManager.getConnection(ConnectionURL);
                    //"jdbc:mysql://192.168.20.11:3306;nepservice", "root","Jackson@9087");
        }catch (SQLException | ClassNotFoundException ex){
            Log.e("Error", ex.getMessage());
        }
          return connection;
    }
}
