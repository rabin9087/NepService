package com.example.nepservice;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import java.util.Objects;

public class HomeActivity extends AppCompatActivity implements
AccommodationFragment.OnFragmentInteractionListener,
        JobsFragment.OnFragmentInteractionListener,
        GroceryStoreFragment.OnFragmentInteractionListener,
        RestaurantFragment.OnFragmentInteractionListener
       {

           DrawerLayout drawerLayout;
           NavigationView navigationView;
           Toolbar toolbar;
           ActionBarDrawerToggle actionBarDrawerToggle;
           ImageButton  accommodationButton, jobButton, groceryButton, restaurantButton, homeSearchButton;

           @SuppressLint("NonConstantResourceId")
           @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigationView);
        toolbar = findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.menu_open,R.string.menu_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        navigationView.setNavigationItemSelectedListener(item ->
        {
            switch (item.getItemId()){
                case R.id.nav_home:
                    Log.i("MENU_DRAWER_TAG", "Search item is clicked");
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, HomeFragment.class, null)
                            .setReorderingAllowed(true).commit();
                    drawerLayout.closeDrawer(GravityCompat.START);
                    break;

                case R.id.nav_myPost:
                    Log.i("MENU_DRAWER_TAG", "MyPost item is clicked");
                    drawerLayout.closeDrawer(GravityCompat.START);
                    break;

                case R.id.nav_settings:
                    Log.i("MENU_DRAWER_TAG", "Settings item is clicked");
                    drawerLayout.closeDrawer(GravityCompat.START);
                    break;

                case R.id.nav_logOut:
                    Log.i("MENU_DRAWER_TAG", "LogOut item is clicked");
                    FragmentManager logOut= getSupportFragmentManager();
                    logOut.beginTransaction().replace(R.id.fragmentContainerView2, RegisterFragment.class, null)
                            .setReorderingAllowed(true).commit();
                    EditText password = findViewById(R.id.PasswordLogIn);
                    password.setText("");
                    drawerLayout.closeDrawer(GravityCompat.START);
                    break;
            }
            return true;
        });


        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            bundle.getString("LI");
        }

        homeSearchButton = findViewById(R.id.homeSearchButton);
        homeSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, SearchFragment.class, null)
                        .setReorderingAllowed(true).commit();
            }
        });


        accommodationButton = findViewById(R.id.accommodationButton);
        accommodationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, AccommodationFragment.class, null)
                        .setReorderingAllowed(true).commit();


            }
        });

        jobButton = findViewById(R.id.jobButton);
        jobButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, JobsFragment.class, null)
                        .setReorderingAllowed(true).commit();
            }
        });

        groceryButton = findViewById(R.id.groceryButton);
        groceryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, GroceryStoreFragment.class, null)
                        .setReorderingAllowed(true).commit();
            }
        });

        restaurantButton = findViewById(R.id.restaurantButton);
        restaurantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView2, RestaurantFragment.class, null)
                        .setReorderingAllowed(true).commit();
            }
        });



       // configureTabLayout();

    }



//    private void configureTabLayout() {
//        TabLayout tabLayout = findViewById(R.id.tab_layout);
//
//        tabLayout.addTab(tabLayout.newTab().setText("Accommodation"));
//        tabLayout.addTab(tabLayout.newTab().setText("Jobs"));
//        tabLayout.addTab(tabLayout.newTab().setText("Grocery Stores"));
//        tabLayout.addTab(tabLayout.newTab().setText("Restaurants"));
//
//        final ViewPager viewPager = findViewById(R.id.pager);
//        final PagerAdapter adapter = new TabPagerAdapter
//                (getSupportFragmentManager(),
//                        tabLayout.getTabCount());
//
//        viewPager.setAdapter(adapter);
//        viewPager.addOnPageChangeListener(new
//                TabLayout.TabLayoutOnPageChangeListener(tabLayout));
//        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                viewPager.setCurrentItem(tab.getPosition());
//            }
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//            }
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//            }
//        });
//    }

    @Override

    public void onFragmentInteraction(Uri uri) {

    }


//           @Override
//           public boolean onCreateOptionsMenu(Menu menu) {
//               MenuInflater menuInflater = getMenuInflater();
//               menuInflater.inflate(R.menu.menu, menu);
//               return true;
//           }
//
//           @Override
//           public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//               switch ((item.getItemId())) {
//                   case R.id.home:
//                       Toast.makeText(this, "Home is selected", Toast.LENGTH_SHORT).show();
//
//                   case R.id.myPost:
//                       Toast.makeText(this, "MyPost is selected", Toast.LENGTH_SHORT).show();
//                       return true;
//
//                   case R.id.setting:
//                       Toast.makeText(this, "Setting is selected", Toast.LENGTH_SHORT).show();
//                       return true;
//
//                   case R.id.logOut:
//                       Toast.makeText(this, "logOut is selected", Toast.LENGTH_SHORT).show();
//                       return true;
//
//                   default:
//                       return super.onOptionsItemSelected(item);
//               }
//           }
    }