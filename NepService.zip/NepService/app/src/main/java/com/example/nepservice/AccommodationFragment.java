package com.example.nepservice;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class AccommodationFragment extends Fragment {

    private final String[] title = {"userName1", "userName2", "userName3", "userName4", "userName5", "userName6"};
    private final String[] detail = {"userName1 description", "userName2 description", "userName3 description",
            "userName4 description", "userName5 description", "userName6 description"};
    private final int[] image = {R.drawable.home,R.drawable.home,R.drawable.home, R.drawable.home,R.drawable.home,R.drawable.home  };

    ImageButton createAccommodationButton;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState
    ) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_accommodations,container, false);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerViewAccommodation);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(new RecyclerAdapter(title, detail, image));

        createAccommodationButton =view.findViewById(R.id.createAccommodationButton);
        createAccommodationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainerView2, new PostNewAccommodationFragment()).commit();
            }
        });

        return view;

    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}