package com.example.nepservice;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class ForgetFragment extends Fragment {

    EditText phoneNumberVerification;
    Button resetPasswordButton;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_forget, container, false);

        phoneNumberVerification = view.findViewById(R.id.phoneNumberVerification);
        resetPasswordButton = view.findViewById(R.id.resetPasswordButton);

        resetPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (phoneNumberVerification.getText().toString().trim().isEmpty()) {
//
//                    if (phoneNumberVerification.getText().toString().trim().length() == 10){
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainerView, new EnterOTPFragment()).commit();

//                    }
//                    else {
//                        //Toast.makeText(ForgetFragment.this, "Please enter correct number", Toast.LENGTH_SHORT);
//                    }
//                } else {
//                    //Toast.makeText(ForgetFragment.this, "Enter mobile number", Toast.LENGTH_SHORT).show();
//                }
            }
        });

        return view;


    }
}