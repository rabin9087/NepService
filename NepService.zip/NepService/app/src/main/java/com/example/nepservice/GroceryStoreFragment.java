package com.example.nepservice;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


public class GroceryStoreFragment extends Fragment {


    ImageButton createGroceryStoreButton;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

           View view = inflater.inflate(R.layout.fragment_grocery_stores, container, false);
        createGroceryStoreButton = view.findViewById(R.id.createGroceryStoreButton);
        createGroceryStoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainerView2, new PostNewGroceryStoresFragment()).commit();
            }
        });


            return view;

    }


    public interface OnFragmentInteractionListener {
    }

}