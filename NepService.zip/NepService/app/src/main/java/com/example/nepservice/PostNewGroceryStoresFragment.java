package com.example.nepservice;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;


public class PostNewGroceryStoresFragment extends Fragment {

    ImageButton backToGroceryStoreFragment;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_post_new_grocery_stores, container, false);
        backToGroceryStoreFragment = view.findViewById(R.id.backToGroceryStoreFragment);
        backToGroceryStoreFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragmentContainerView2, new PostNewGroceryStoresFragment()).commit();
            }
        });

        return view;
    }
}